import pandas as pd
from joblib import load
import numpy as np
import json
import asyncio
import websockets
from datetime import datetime
import yaml

# Load konfigurasi dari file settings.yaml
with open('settings.yaml', 'r') as file:
    config = yaml.safe_load(file)

host = config['server']['host']
port = config['server']['port']
log_file = config['logging']['log_file']

# Load model dan scaler
model = load('ai_jb.joblib')
scaler = load('ai_scal.joblib')

# Fungsi untuk prediksi menggunakan model AI
def ai(features):
    scaled_features = scaler.transform(features)
    prediction = model.predict(scaled_features)
    return prediction[0]

# Fungsi untuk menangani pesan yang diterima dari client (scanner)
async def handle_message(websocket, path):
    async for message in websocket:
        data = json.loads(message)
        
        features = np.array([[data["dest_port"], data["flow_duration"], data["total_fwd_packets"], 
                              data["total_bwd_packets"], data["total_len_fwd_packets"], 
                              data["total_len_bwd_packets"], data["flow_bytes_s"], 
                              data["flow_packets_s"]]])
        
        prediction = ai(features)
        prediction_label = "Normal" if prediction == 0 else "DDoS"
        
        log_message = (
            f"{datetime.now()} - "
            f"Destination Port: {data['dest_port']}, Flow Duration: {data['flow_duration']}, "
            f"Total Fwd Packets: {data['total_fwd_packets']}, Total Backward Packets: {data['total_bwd_packets']}, "
            f"Total Length of Fwd Packets: {data['total_len_fwd_packets']}, Total Length of Bwd Packets: {data['total_len_bwd_packets']}, "
            f"Flow Bytes/s: {data['flow_bytes_s']:.2f}, Flow Packets/s: {data['flow_packets_s']:.2f} - "
            f"Prediction: {prediction_label}"
        )
        
        print(log_message)
        
        # Menyimpan log ke file CSV
        log_df = pd.DataFrame([{
            'Timestamp': datetime.now(),
            'Destination Port': data['dest_port'],
            'Flow Duration': data['flow_duration'],
            'Total Fwd Packets': data['total_fwd_packets'],
            'Total Backward Packets': data['total_bwd_packets'],
            'Total Length of Fwd Packets': data['total_len_fwd_packets'],
            'Total Length of Bwd Packets': data['total_len_bwd_packets'],
            'Flow Bytes/s': data['flow_bytes_s'],
            'Flow Packets/s': data['flow_packets_s'],
            'Prediction': prediction_label
        }])
        
        log_df.to_csv(log_file, mode='a', header=False, index=False)
        
        # Mengirimkan respon ke client
        await websocket.send(f"Prediction: {prediction_label}")

# Memulai server WebSocket dengan konfigurasi dari settings.yaml
start_server = websockets.serve(handle_message, host, port)
print('''
        ___           ___           ___           ___           ___                   
     /  /\         /  /\         /  /\         /  /\         /  /\          ___     
    /  /::\       /  /::\       /  /::\       /  /::|       /  /::\        /__/\    
   /  /:/\:\     /__/:/\:\     /  /:/\:\     /  /:|:|      /  /:/\:\       \  \:\   
  /  /::\ \:\   _\_ \:\ \:\   /  /:/  \:\   /  /:/|:|__   /  /::\ \:\       \__\:\  
 /__/:/\:\_\:\ /__/\ \:\ \:\ /__/:/ \  \:\ /__/:/ |:| /\ /__/:/\:\ \:\      /  /::\ 
 \__\/  \:\/:/ \  \:\ \:\_\/ \  \:\  \__\/ \__\/  |:|/:/ \  \:\ \:\_\/     /  /:/\:\
      \__\::/   \  \:\_\:\    \  \:\           |  |:/:/   \  \:\ \:\      /  /:/__\/
      /  /:/     \  \:\/:/     \  \:\          |__|::/     \  \:\_\/     /__/:/     
     /__/:/       \  \::/       \  \:\         /__/:/       \  \:\       \__\/      
     \__\/         \__\/         \__\/         \__\/         \__\/              
      Agent_Version : 0.0.1(Pre_Alpha)    
''')
print(f"AI server started at ws://{host}:{port}")
asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
