import pyshark
import websocket
import json
import yaml

def read_config_yaml(filepath):
    with open(filepath, 'r') as file:
        return yaml.safe_load(file)

def analyze_packet(packet, ws, excluded_ports):
    try:
        dest_port = int(packet[packet.transport_layer].dstport)
        if dest_port in excluded_ports:
            return  # Skip processing if port is excluded
        
        flow_duration = float(packet.sniff_timestamp)
        total_fwd_packets = 1 if packet.ip.src == packet.eth.src else 0
        total_bwd_packets = 1 if packet.ip.dst == packet.eth.src else 0
        total_len_fwd_packets = int(packet.length) if total_fwd_packets else 0
        total_len_bwd_packets = int(packet.length) if total_bwd_packets else 0
        flow_bytes_s = int(packet.length) / flow_duration if flow_duration > 0 else 0
        flow_packets_s = 1 / flow_duration if flow_duration > 0 else 0

        features = {
            "dest_port": dest_port,
            "flow_duration": flow_duration,
            "total_fwd_packets": total_fwd_packets,
            "total_bwd_packets": total_bwd_packets,
            "total_len_fwd_packets": total_len_fwd_packets,
            "total_len_bwd_packets": total_len_bwd_packets,
            "flow_bytes_s": flow_bytes_s,
            "flow_packets_s": flow_packets_s
        }

        try:
            ws.send(json.dumps(features))
        except websocket.WebSocketException as e:
            print(f"WebSocket error: {e}")

    except AttributeError:
        pass

def start_realtime_scanning(config):
    ws_url = f"ws://{config['websocket_host']}:{config['websocket_port']}"
    excluded_ports = config.get('excluded_ports', [])
    connected = False
    while not connected:
        try:
            ws = websocket.WebSocket()
            ws.connect(ws_url)
            connected = True
            print("Connected to AI server")

            capture = pyshark.LiveCapture(interface=config['network_interface'])
            print("Starting real-time network scanning...")

            for packet in capture.sniff_continuously():
                analyze_packet(packet, ws, excluded_ports)

        except websocket.WebSocketException as e:
            print(f"WebSocket connection error: {e}")
            time.sleep(5)  # Tunggu sebelum mencoba lagi
        except Exception as e:
            print(f"Error: {e}")
        finally:
            ws.close()

if __name__ == "__main__":
    config = read_config_yaml('config.yaml')
    start_realtime_scanning(config)
